import React from 'react'
import Header from './components/Header'
import Hero from './components/Hero'
import Services from './components/Services'
import Contact from './components/Contact'
import Demo from '@/components/ui/demo'

function App() {
  return (
    <div className="min-h-screen bg-white">
      <Header />
      {/* Demo of the AnomalousMatterHero component (full-screen). Comment out to hide. */}
      <div className="relative h-screen">
        <Demo />
      </div>
      <Hero />
      <Services />
      <Contact />
      <footer className="bg-white border-t border-gray-200">
        <div className="mx-auto max-w-6xl px-6 py-10 text-center">
          <p className="text-sm text-gray-600">
            © {new Date().getFullYear()} Goldhorn Consulting. All rights reserved.
          </p>
        </div>
      </footer>
    </div>
  )
}

export default App
