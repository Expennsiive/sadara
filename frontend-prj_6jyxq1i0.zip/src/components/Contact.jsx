import React, { useState } from 'react'

function Contact() {
  const [form, setForm] = useState({ name: '', email: '', message: '' })
  const [status, setStatus] = useState('')

  const handleChange = (e) => {
    const { name, value } = e.target
    setForm((f) => ({ ...f, [name]: value }))
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    setStatus('Thanks — we will get back to you shortly.')
    setForm({ name: '', email: '', message: '' })
  }

  return (
    <section id="contact" className="bg-white">
      <div className="mx-auto max-w-6xl px-6 py-20">
        <div className="grid lg:grid-cols-2 gap-12 items-start">
          <div>
            <h2 className="text-3xl font-bold text-gray-900">Contact</h2>
            <p className="mt-3 text-gray-700">Send a note and we’ll respond promptly.</p>
            <div className="mt-6 rounded-xl border border-gray-200 bg-gradient-to-br from-white to-yellow-50 p-6 shadow-sm">
              <p className="text-gray-700"><span className="font-semibold">Email:</span> hello@goldhorn.consulting</p>
              <p className="text-gray-700 mt-2"><span className="font-semibold">Location:</span> Remote-first</p>
            </div>
          </div>

          <form onSubmit={handleSubmit} className="rounded-2xl border border-gray-200 bg-white p-6 shadow-sm">
            <div className="grid sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700">Name</label>
                <input name="name" value={form.name} onChange={handleChange} type="text" required
                       className="mt-1 w-full rounded-md border border-gray-300 bg-white px-3 py-2 text-gray-900 placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-yellow-400" />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700">Email</label>
                <input name="email" value={form.email} onChange={handleChange} type="email" required
                       className="mt-1 w-full rounded-md border border-gray-300 bg-white px-3 py-2 text-gray-900 placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-yellow-400" />
              </div>
            </div>
            <div className="mt-4">
              <label className="block text-sm font-medium text-gray-700">Message</label>
              <textarea name="message" value={form.message} onChange={handleChange} rows="4" required
                        className="mt-1 w-full rounded-md border border-gray-300 bg-white px-3 py-2 text-gray-900 placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-yellow-400" />
            </div>
            <button type="submit" className="mt-6 inline-flex items-center justify-center px-5 py-3 rounded-lg font-semibold text-white shadow-sm transition-colors"
                    style={{ backgroundColor: '#d4af37' }}>
              Send message
            </button>
            {status && <p className="mt-3 text-sm text-gray-700">{status}</p>}
          </form>
        </div>
      </div>
    </section>
  )
}

export default Contact
