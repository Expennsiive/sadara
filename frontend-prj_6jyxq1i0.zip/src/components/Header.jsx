import React from 'react'

function Header() {
  return (
    <header className="w-full">
      <div className="mx-auto max-w-6xl px-6 py-5 flex items-center justify-between">
        <a href="#top" className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-full bg-[radial-gradient(circle_at_30%_30%,#f7e27f,#d4af37_60%,#a47b1a_100%)] shadow-sm" />
          <span className="text-xl font-semibold tracking-tight" style={{ color: '#d4af37' }}>
            Goldhorn Consulting
          </span>
        </a>
        <nav className="hidden sm:flex items-center gap-6">
          <a href="#services" className="text-gray-700 hover:text-gray-900 transition-colors">Services</a>
          <a href="#contact" className="text-gray-700 hover:text-gray-900 transition-colors">Contact</a>
        </nav>
      </div>
    </header>
  )
}

export default Header
