import React from 'react'

function Hero() {
  return (
    <section id="top" className="relative overflow-hidden">
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute -top-40 -left-40 w-[28rem] h-[28rem] rounded-full opacity-30 blur-3xl" style={{
          background: 'radial-gradient(circle, #f7e27f 0%, #d4af37 35%, transparent 70%)'
        }} />
        <div className="absolute -bottom-40 -right-40 w-[30rem] h-[30rem] rounded-full opacity-20 blur-3xl" style={{
          background: 'radial-gradient(circle, #fff7cc 0%, #f5e6a2 40%, transparent 75%)'
        }} />
      </div>

      <div className="mx-auto max-w-6xl px-6 py-24 sm:py-32">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div>
            <h1 className="text-4xl sm:text-5xl font-extrabold leading-tight text-gray-900">
              Strategic guidance to help your business grow
            </h1>
            <p className="mt-6 text-lg text-gray-700">
              Goldhorn Consulting provides clear, practical consulting for founders and teams. We focus on what matters: meaningful outcomes, efficient processes, and confident decision-making.
            </p>
            <div className="mt-8 flex flex-wrap items-center gap-4">
              <a href="#contact" className="inline-flex items-center justify-center px-5 py-3 rounded-lg font-semibold text-white shadow-sm transition-colors"
                 style={{ backgroundColor: '#d4af37' }}>
                Get in touch
              </a>
              <a href="#services" className="inline-flex items-center justify-center px-5 py-3 rounded-lg font-semibold text-gray-900 bg-white border border-gray-200 shadow-sm hover:bg-gray-50 transition-colors">
                Our services
              </a>
            </div>
          </div>

          <div className="relative rounded-2xl bg-white shadow-xl border border-gray-100 p-6">
            <div className="grid grid-cols-2 gap-4">
              <div className="rounded-xl bg-gradient-to-br from-white to-yellow-50 border border-gray-200 p-5">
                <h3 className="font-semibold text-gray-900">Clarity</h3>
                <p className="mt-2 text-sm text-gray-600">Straightforward frameworks for better decisions.</p>
              </div>
              <div className="rounded-xl bg-gradient-to-br from-white to-yellow-50 border border-gray-200 p-5">
                <h3 className="font-semibold text-gray-900">Efficiency</h3>
                <p className="mt-2 text-sm text-gray-600">Lean processes to reduce cost and waste.</p>
              </div>
              <div className="rounded-xl bg-gradient-to-br from-white to-yellow-50 border border-gray-200 p-5">
                <h3 className="font-semibold text-gray-900">Growth</h3>
                <p className="mt-2 text-sm text-gray-600">Practical plans to move from idea to impact.</p>
              </div>
              <div className="rounded-xl bg-gradient-to-br from-white to-yellow-50 border border-gray-200 p-5">
                <h3 className="font-semibold text-gray-900">Support</h3>
                <p className="mt-2 text-sm text-gray-600">Hands-on guidance when you need it.</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}

export default Hero
