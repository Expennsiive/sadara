import React from 'react'

const services = [
  {
    title: 'Strategy & Planning',
    desc: 'Define priorities, align teams, and build a clear roadmap that drives outcomes.'
  },
  {
    title: 'Operations & Process',
    desc: 'Design lean systems that reduce friction and help your organization scale.'
  },
  {
    title: 'Go-to-Market',
    desc: 'Clarify positioning, messaging, and motions to reach the right customers.'
  },
  {
    title: 'Advisory & Coaching',
    desc: 'Practical support for founders and leaders to make confident decisions.'
  },
]

function Services() {
  return (
    <section id="services" className="bg-white">
      <div className="mx-auto max-w-6xl px-6 py-20">
        <h2 className="text-3xl font-bold text-gray-900">Services</h2>
        <p className="mt-3 text-gray-700">Simple, effective consulting designed around your goals.</p>

        <div className="mt-10 grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {services.map((s) => (
            <div key={s.title} className="rounded-xl border border-gray-200 bg-gradient-to-br from-white to-yellow-50 p-5 shadow-sm">
              <h3 className="font-semibold text-gray-900">{s.title}</h3>
              <p className="mt-2 text-sm text-gray-700">{s.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}

export default Services
