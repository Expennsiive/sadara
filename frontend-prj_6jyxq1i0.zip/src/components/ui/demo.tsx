import React from "react";
import { AnomalousMatterHero } from "@/components/ui/anomalous-matter-hero";

function Demo() {
  return (
    <AnomalousMatterHero
      title="Goldhorn Consulting"
      subtitle="Strategy. Systems. Scale."
      description="We help ambitious teams design resilient systems, streamline operations, and scale with confidence."
    />
  );
}

export default Demo;
